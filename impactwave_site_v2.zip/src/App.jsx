import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'

function Home() {
  return <div className="p-6 text-center"><h1 className="text-3xl font-bold">Welcome to ImpactWave</h1></div>
}
function About() {
  return <div className="p-6"><h2 className="text-2xl font-bold">About ImpactWave</h2><p>Driving Impact, Creating Waves of Change.</p></div>
}
function Programs() {
  return <div className="p-6"><h2 className="text-2xl font-bold">Our Programs</h2><p>We focus on Health, Youth Empowerment, Climate, and Women Support.</p></div>
}
function Resources() {
  return <div className="p-6"><h2 className="text-2xl font-bold">Resources</h2><p>Insights, reports, and community stories.</p></div>
}
function Contact() {
  return <div className="p-6"><h2 className="text-2xl font-bold">Contact Us</h2><p>Reach us at info@impactwave.org</p></div>
}

export default function App() {
  return (
    <div>
      <nav className="flex justify-between p-4 bg-blue-600 text-white">
        <div className="font-bold">ImpactWave</div>
        <div className="space-x-4">
          <Link to="/">Home</Link>
          <Link to="/about">About</Link>
          <Link to="/programs">Programs</Link>
          <Link to="/resources">Resources</Link>
          <Link to="/contact">Contact</Link>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/programs" element={<Programs />} />
        <Route path="/resources" element={<Resources />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
      <footer className="p-4 bg-gray-100 text-center text-sm">
        © {new Date().getFullYear()} ImpactWave. All rights reserved.
      </footer>
    </div>
  )
}
